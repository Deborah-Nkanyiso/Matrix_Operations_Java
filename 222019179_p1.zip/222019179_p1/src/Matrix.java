/**
 * @author DN MBOYI 222019179_p1
 * Matrix class that is implemented by the IMatrix
 */


public class Matrix <T> implements IMatrix<T>
{
	private T[][] matrix;
	private int row;
	private int column;
	
	/*
	 * Create a constructor to initialize the Matrix
	 */
	public Matrix(int row, int column)
	{
		this.row= row;
		this.column= column;

	}
	
	 /**
     * The number of rows in this Matrix
     * @return The number of rows
     */
	@Override
	public Integer numberRows() 
	{
		return row;
	}

	 /**
     * The number of columns in this Matrix
     * @return The number of columns
     */
	@Override
	public Integer numberCols() 
	{
		return column;
	}

	 /**
     * Returns an IMatrix<T> that contains the specified row. This will be a nx1
     * Matrix.
     * @return An IMatrix<T> that contains the specified row.
     * @throws MatrixException if the row number is invalid.
     */
	@Override
	public IMatrix<T> getRow(Integer i) throws MatrixException 
	{
        if (i < 0 || i >= row) throw new MatrixException("Error!! Incorrect row index");
		Matrix<T> RMatrix = new Matrix<>(1,column);
		for(int j= 0; j< column;j++)
		{
			RMatrix.matrix[0][j]= matrix[i][j];
			
		}
		
		return RMatrix;
	}

	/**
     * Returns an IMatrix<T> that contains the specified column. This will be an
     * 1xn Matrix.
     * @return An IMatrix<T> that contains the specified column
     * @throws MatrixException if the column number is invalid
     */
	@Override
	public IMatrix<T> getCol(Integer j) throws MatrixException 
	{
        if (j < 0 || j >= column) throw new MatrixException("Error!! Incorrect column index");

		Matrix<T> CMatrix = new Matrix<>(row,1);
	     for(int i= 0; i< row;i++)
	{
		CMatrix.matrix[i][j]= matrix[i][j];
		
	}
		return CMatrix;
	}
	
	 /**
     * Add another Matrix to the current matrix. A new matrix should be returned
     * @param otherMatrix The other matrix that should be added to this matrix.
     */
	@Override
	public T getElement(Integer i, Integer j) throws MatrixException 
	{
		if(i<0 || i>= row || j<0 ||j>= column) throw new MatrixException("The Element you are trying to get cannot be found!");
		return matrix[i][j];
	}
	
	
/*
 * Addition of a matrix
 */
	@Override
	public IMatrix<T> addMatrix(IMatrix<T> otherMatrix) throws MatrixException 
	{
		
		Matrix<T> newMatrix= new Matrix<T>(row, column);
		for(int i=0; i< row; i++)
		{
			for(int j=0; j< column; j++)
			{
                newMatrix.matrix[i][j] = (T) Integer.valueOf(((Integer) matrix[i][j]) + (Integer) otherMatrix.getElement(i, j));
			}
		}
		
		return newMatrix;
	}

	/*
	 * Addition of a scalar to a matrix
     * @return A new matrix  that contains the result.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public IMatrix<T> addScalar(Integer c) throws MatrixException 
	{
		Matrix<T> newMatrix= new Matrix<T>(row, column);
		for(int i=0; i< row; i++)
		{
			for(int j=0; j< column; j++)
			{
				newMatrix.matrix[i][j]= (T) Integer.valueOf(((Integer)matrix[i][j])+ c);
			}
		}
		return newMatrix;
	}

	@SuppressWarnings("unchecked")
	@Override
	public IMatrix<Double> addScalar(Double c) throws MatrixException 
	{
		Matrix<Double> newMatrix= new Matrix<Double>(row, column);
		for(int i=0; i< row;i++)
		{
			for(int j=0; j<column;j++)
			{
				newMatrix.matrix[i][j]= (Double) Double.valueOf(((Double)matrix[i][j])+c);
			}
		}
		return (IMatrix<Double>) newMatrix;
	}

	@Override
	public IMatrix<T> multiplyScalar(Integer c) throws MatrixException 
	{
		Matrix<T> newMatrix= new Matrix<T>(row, column);
		for(int i=0; i<row;i++)
		{
			for(int j=0; j<column; j++)
			{
				newMatrix.matrix[i][j]= (T) Integer.valueOf(((Integer)matrix[i][j])*c);
			}
		}
		return newMatrix;
	}

	@Override
	public IMatrix<Double> multiplyScalar(Double c) throws MatrixException 
	{

		Matrix<Double> newMatrix= new Matrix<Double>(row, column);
		for(int i=0; i<row;i++)
		{
			for(int j=0; j<column; j++)
			{
				newMatrix.matrix[i][j]= (Double) Double.valueOf(((Double)matrix[i][j])*c);
			}
		}
		return  newMatrix;
	}

	@SuppressWarnings("unchecked")
	@Override
	public IMatrix<T> multiplyMatrix(IMatrix<T> otherMatrix) throws MatrixException
	{
		
	        Matrix<T> newMatrix = new Matrix<>(row, otherMatrix.numberCols());
	        for (int i = 0; i < row; i++) 
	        {
	            for (int j = 0; j < otherMatrix.numberCols(); j++)
	            {
	                T sum = null; 
	                for (int n = 0; n < row; n++)
	                {
	                    sum = (T) Integer.valueOf(((Integer) sum) + ((Integer) matrix[i][j]) * ((Integer) otherMatrix.getElement(i, j)));
	                }
	                newMatrix.matrix[i][j] = sum;
	            }
	        }
	        return newMatrix;
	    
	}

	@Override
	public IMatrix<T> transpose() 
	{
		Matrix<T> TMatrix= new Matrix<T>(row, column);
		for(int i =0; i<row; i++)
		{
			for(int j=0; j< column; j++)
			{
				TMatrix.matrix[i][j]=matrix[i][j];
			}
		}
		return TMatrix;
	}
	
	@Override
    public String toString()
	{
        return matrix + " " + row + " " + column;
		
    }
	

}
