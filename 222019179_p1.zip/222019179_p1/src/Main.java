/*
 * @DN MBOYI 
 * 222019179_p1
 * 
 */
 
	public class Main 
	{

		public static void main(String[] args) 
		{

			


				/*Integer[][] ResultsA = { { 1, 2 }, { 8, 5 } };

				Integer[][] ResultsB = { { 5, 6 }, { 7, 8 } };

				Matrix<Integer> matrixA = new Matrix<>(ResultsA);

				Matrix<Integer> matrixB = new Matrix<>(ResultsB);



				System.out.println("Matrix A:");

				System.out.println(matrixA);



				System.out.println("Matrix B:");

				System.out.println(matrixB);



				System.out.println("Matrix A + Matrix B:");

				System.out.println(matrixA.addMatrix(matrixB));



				System.out.println("Matrix A * 2:");

				System.out.println(matrixA.multiplyScalar(2));



				System.out.println("Matrix A * Matrix B:");

				System.out.println(matrixA.multiplyMatrix(matrixB));



				System.out.println("Transpose of Matrix A:");

				System.out.println(matrixA.transpose());*/


		}

}
